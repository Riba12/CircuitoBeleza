
export default function LogoFixa(){

    return(
            <img src="logo1.png" className="w-9 md:w-20"/>
    );
}